// 섹션 이동
function goSection(sectionName) {
    const section = document.querySelectorAll('.sec');
    section.forEach((item) => {
        item.classList.add('hidden');
    })
    document.querySelector(`[data-section="${sectionName}"]`).classList.remove('hidden');

    if (sectionName === 'admin') renderTable();
    if (sectionName === 'user') renderUserList();
}

// 공통 팝업
function showPop(popName,) {
    document.querySelector(`[data-pop="${popName}"]`).style.display = 'flex';
    document.querySelector('html, body').style.overflowY = 'hidden';
}
function hidePop() {
    const pop = document.querySelectorAll('.pop');
    pop.forEach(item => item.style.display = 'none');
    document.querySelector('html, body').style.overflowY = 'auto';
}

// 제품 목록
let products = [
    { id: 1, name: "콜라", price: 1000, stock: 100, revenue: 0},
    { id: 2, name: "사이다", price: 1000, stock: 100, revenue: 0},
    { id: 3, name: "웰치스", price: 2000, stock: 50, revenue: 0},
    { id: 4, name: "핫식스", price: 2000, stock: 30, revenue: 0},
    { id: 5, name: "헛개수", price: 2000, stock: 10, revenue: 0},
];
console.log(products);

/**
 * user 
 */
function renderUserList() {
    const div = document.querySelector('#card-group');
    div.innerHTML = ''; // 버튼들 초기화
    products.forEach((item) => {
        div.innerHTML += `
            <button class="btn btn-drink" data-id="${item.id}" onclick="selectProd(this)">
                ${item.name}
            </button>
        `;
    });
}
// 음료 선택
function selectProd(ele) {
    showPop('pop-buy');
    const id = ele.getAttribute('data-id');
    currentState(id);
}

// 음료 선택 팝업 > 상세 내용 뿌리기
let currentProdId = '';
function currentState(target) {
    const id = Number(target); // 문자열로 받은 인자값 숫자로 변환
    const selected = products.find(p => p.id === id); // products 배열에서 id 일치하는 제품 찾기
    document.querySelector('#state-box').innerHTML = `
        <dt>선택 음료</dt>
        <dd>${selected.name}</dd>
        <dt>개당 금액</dt>
        <dd>${selected.price.toLocaleString()}원</dd>
        <dt>현재 재고</dt>
        <dd id="prod-stock">${selected.stock}</dd>
    `;
    currentProdId = selected;
}

// 음료 선택 팝업 > 저장
let input = document.querySelector('#prod-count');
function buyProd() {
    let inputValue = input.value;
    let isValid = true;

    if (inputValue.trim().length === 0) {
        alert('개수를 입력하세요.');
        isValid = false;
    } else if (currentProdId.stock < inputValue) {
        alert(`⚠️ 재고 부족 - 현재 ${currentProdId.name} 재고는 ${currentProdId.stock}개입니다.`);
        isValid = false;
    }

    if (isValid) {
        document.querySelector('#prod-result').textContent = `
            ${currentProdId.name} ${inputValue}개가 판매되었습니다.
            (${(currentProdId.price * inputValue).toLocaleString()}원)`;
        document.querySelector('#state-box #prod-stock').style.color = '#007bff';
        document.querySelector('#state-box #prod-stock').textContent = currentProdId.stock - Number(inputValue);
        currentProdId.stock -= Number(inputValue);
        currentProdId.revenue += currentProdId.price * inputValue;

        input.value = '';
        input.focus();
        console.log('result', products);
    }
    console.log('수익', currentProdId.revenue);
}
function closeBuyPop() {
    hidePop();
    if (!(input.value.trim().length === 0)) {
        document.querySelector('#prod-count').value = '';
        document.querySelector('#prod-result').textContent = '';
        document.querySelector('#state-box #prod-stock').style.color = '';
    }
}


/**
 * 관리자 
 */
// 테이블 뿌리기
function renderTable() {
    const tbody = document.querySelector('[data-id="table-tbody"]');
    tbody.innerHTML = '';

    // 각 product마다 tr 추가
    products.forEach((item, idx) => {
        tbody.innerHTML += `
            <tr>
                <td>${idx + 1}</td>
                <td>${item.name}</td> 
                <td>${item.price.toLocaleString()}원</td>
                <td data-id="td-stock-${idx}">${item.stock}</td>
            </tr>
        `;
    });
}

// 1. 재고 변경 팝업
function renderStockPop() {
    const popStock = document.querySelector('#stock-box');
    let html = '';
    products.forEach((item, idx) => {
        html += `
            <div class="list-item">
                <strong>${item.name}</strong>
                <input type="number" id="stock-input-${idx}" value="${item.stock}" />
            </div>
        `;
    });
    popStock.innerHTML = html;
    showPop('pop-stock');   
}

// 1. 재고 변경 팝업 > 저장
function saveStockPop() {
    products.forEach((item, idx) => {
        const input = document.querySelector(`#stock-input-${idx}`);
        const newValue = Number(input.value);
        if (!isNaN(newValue) && newValue >= 0) {
        item.stock = newValue;
        }
    });
    renderTable();
    hidePop();
}

// 2. 제품 변경 팝업 > 테이블 뿌리기
function renderPopupTable() {
    const tbody = document.querySelector('.pop [data-id="table-tbody"]');
    tbody.innerHTML = '';

    products.forEach((item, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${idx + 1}</td>
            <td>${item.name}</td>
            <td>${item.price.toLocaleString()}원</td>
            <td>${item.stock}</td>
            <td><button type="button" id="" onclick="removeProd(this)";>삭제</button></td>
        `;
        tbody.appendChild(tr);
    });
}

// 2. 제품 변경 팝업 > 랜딩
function renderProdPop() {
    showPop('pop-prod');
    renderPopupTable();
}

// 2. 제품 변경 팝업 > 추가
function addProd() {
    if (!(products.length >= 5)) {
        const inputs = document.querySelectorAll('#add-form input');

        // input 값을 배열로 추출해서 빈 값이 있는지 확인
        const isAnyEmpty = Array.from(inputs).some(input => input.value.trim() === '');

        if (isAnyEmpty) {
            alert('모든 값을 입력해주세요!');
            return;
        }

        const newProduct = {
            id: products.length+1,
            name: inputs[0].value,
            price: parseInt(inputs[1].value, 10),
            stock: parseInt(inputs[2].value, 10),
            revenue: 0,
        };

        products.push(newProduct);
        console.log('last products', products);

        // 입력창 초기화
        inputs.forEach(input => input.value = '');

        renderTable();
        renderPopupTable();
        
    } else {
        alert('제품은 최대 5개까지만 등록할 수 있습니다.\n기존 제품을 삭제한 후 등록해주세요.');
        return;
    }

    
}

// 2. 제품 변경 팝업 > 삭제
function removeProd(target) {
    const tr = target.parentElement.parentElement;
    const tbody = tr.parentElement;

    // 몇 번째 tr인지 index 구하기
    const index = Array.from(tbody.children).indexOf(tr); // ← 이게 핵심!

    // products에서 해당 index 제거
    products.splice(index, 1);

    // 새로 index번호 부여
    products.forEach((item, idx) => {
        item.id = idx + 1;
    });

    // DOM에서 삭제
    tr.remove();

    renderTable();
    renderPopupTable();

    console.log('삭제 후 products:', products);
}

// 3. 수익 보기 팝업
function renderRevenue() {
    const popRev = document.querySelector('#rev-box');
    let html = '';
    let totalRevenue = 0; 

    products.forEach((item) => {
        html += `
            <div class="list-item">
                <strong>${item.name}</strong>
                <span>${item.revenue.toLocaleString()}</span>
            </div>
        `;
        totalRevenue += item.revenue;
    });
    popRev.innerHTML = html;

    document.querySelector('#total').innerHTML = `
        <div class="list-item">
            <strong>총합</strong>
            <span>${totalRevenue.toLocaleString()}</span>
        </div>
    `;

    showPop('pop-revenue');   
}